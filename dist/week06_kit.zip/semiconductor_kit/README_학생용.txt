반도체 공정 데이터 분석 — 학생용 실습 키트

이 폴더의 구조를 바꾸지 마세요.
노트북과 Orange 파일은 서로의 위치를 기준으로 데이터를 찾습니다.
파일을 하나씩 꺼내 다른 곳으로 옮기면 데이터를 찾지 못합니다.

[폴더 안내]
- notebooks/student/      주피터 노트북 (weekXX_student.ipynb)
- data/weekly/weekXX/     실습 데이터 (CSV)
  - orange/               Orange에서 여는 같은 데이터 (.tab)
- orange3/weekXX/         Orange 워크플로
  - ..._start.ows         시작 파일 (데이터가 이미 연결된 File 위젯에서 출발)
  - ..._done.ows          완성본 (막혔을 때 열어 보기)
- docs/setup.html          수강 전 준비(설치·키트 사용법) 안내

[사용법]
1. 압축을 푼 폴더를 그대로 둡니다.
2. 노트북: Jupyter에서 notebooks/student 폴더의 weekXX_student.ipynb를 엽니다.
3. Orange: Orange 3.35에서 File > Open으로 orange3/weekXX 폴더의 _start.ows를 엽니다.
4. File 위젯에 빨간 글씨가 보이거나 데이터가 비어 있으면,
   압축을 푼 폴더 구조가 바뀌지 않았는지 먼저 확인하세요.

이 키트의 모든 데이터는 교육용 가상 데이터이며 실제 기업 생산 데이터가 아닙니다.
